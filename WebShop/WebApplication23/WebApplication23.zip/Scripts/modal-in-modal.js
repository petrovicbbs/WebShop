﻿$('#delDobClose').click(function () {
    $('#delDob').modal('toggle');
});
